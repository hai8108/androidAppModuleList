package com.dingding.ddframe.ddbase.commons.Entitys;

/**
 * Created by zzz on 15/8/19.
 */
public class User {

    private String name ;
    private String email ;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
