package simcpux.sourceforge.net;

/**
 * Created by Administrator on 2015/11/12.
 */
public class Constant {

    public final static String ROOT_DIR = "/ThirdLoginAndShare/";

    public static final String WX_AppID = "wxd930ea5d5a258f4f";

    public static final String WX_AppSecret = "943d690bd5020ae629c20281e53bc334";

    //	public static final String QQ_AppID = "222222";
    public static final String QQ_AppID = "1104826608";

    public static final String QQ_AppSecret = "PsLMILpDwU6QDNOk";
}
