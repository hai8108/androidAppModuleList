package simcpux.sourceforge.net;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Administrator on 2015/5/18.
 */
public class FileUtils {

    public final static String PATH =
            Environment.getExternalStorageDirectory() + Constant.ROOT_DIR
                    + "image/";
    public final static String NAME = "welcome_bg.png";
    public final static String SHARE__LOGO_NAME = "share_logo.png";
    private static File dir = new File(PATH);
    private static File file = null;

    private final static int POOL_SIZE = 3;
    private static int cpuNums = Runtime.getRuntime().availableProcessors();
    private static ExecutorService executor = Executors
            .newFixedThreadPool(cpuNums * POOL_SIZE);

    public static String saveBitmap(Bitmap bitmap, String name) {
        if (!sdCardMounted()) {
            return null;
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
        file = new File(dir, name);
        if (file.exists() && file.length() > 5 * 1024 * 1024) {
            file.delete();
        }
        try {
            file.createNewFile();
            executor.execute(new Handler(bitmap));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file.getPath();
    }

    public static Bitmap getBitmap(String name) {
        if (!sdCardMounted()) {
            return null;
        }
        if (!dir.exists()) {
            return null;
        }
        file = new File(dir, name);
        Bitmap bitmap = null;
        BufferedInputStream is = null;
        try {
            is = new BufferedInputStream(new FileInputStream(file));
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (is!=null){
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return bitmap;
    }

    /**
     * 检查是否装在sd卡
     *
     * @return
     */
    private static boolean sdCardMounted() {
        final String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED) && !state
                .equals(Environment.MEDIA_MOUNTED_READ_ONLY)) {
            return true;
        }
        return false;
    }

    static class Handler implements Runnable {

        private Bitmap bitmap;

        public Handler(Bitmap bitmap) {
            this.bitmap = bitmap;
        }

        @Override
        public void run() {
            synchronized (file) {
                BufferedOutputStream os = null;
                try {
                    os = new BufferedOutputStream(new FileOutputStream(file));
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
                    os.close();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        os.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

}
