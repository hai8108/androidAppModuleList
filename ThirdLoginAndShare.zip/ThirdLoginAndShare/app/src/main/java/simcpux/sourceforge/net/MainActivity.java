package simcpux.sourceforge.net;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

import org.json.JSONObject;

import simcpux.sourceforge.net.wxapi.WXEntryActivity;

/**
 * Created by Administrator on 2015/11/12.
 */
public class MainActivity extends Activity implements
        WXEntryActivity.WXLoginListener{

    private LinearLayout wechatLogin;

    private LinearLayout qqLogin;

    private ImageView shareView;

    private ShareDialog shareDialog;


    // IWXAPI 是第三方app和微信通信的openapi接口
    private IWXAPI api;
    private Tencent mTencent;
    private QQListener listener;

    private final String PLAT_QQ  = "qq";
    private final String PLAT_WEIXIN  = "weixin";

    private StudentLoadingLayout loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
    }

    private void findView(){
        wechatLogin = (LinearLayout)findViewById(R.id.login_third_wechat);
        qqLogin = (LinearLayout)findViewById(R.id.login_third_qq);
        shareView = (ImageView)findViewById(R.id.third_share);
        loadingView = (StudentLoadingLayout)findViewById(R.id.loading);


        wechatLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetWorkTypeUtils.isNetAvailable()) {
                    Util.showToast(R.string.net_null);
                } else {
                    openWXinClient();
                }
            }
        });

        qqLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetWorkTypeUtils.isNetAvailable()) {
                    Util.showToast(R.string.net_null);
                } else {
                    openQQClient();
                }
            }
        });

        shareView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetWorkTypeUtils.isNetAvailable()) {
                    Util.showToast(R.string.net_null);
                    return;
                }
                final String discription = "我就是叶良辰,不服来战！";
                final String shareUrl = "http://www.baidu.com";
                if (shareDialog == null) {
                    shareDialog = new ShareDialog(MainActivity.this, new ShareDialog.ShareCallBack() {
                        @Override
                        public void cancel() {

                        }

                        @Override
                        public void wechatShare() {
                            ShareManager.getInstance(MainActivity.this).onWeixinShare(
                                    ShareManager.WEIXIN_SHARE_TYPE_TALK, discription, shareUrl);
                        }

                        @Override
                        public void wechatFridsShare() {
                            ShareManager.getInstance(MainActivity.this).onWeixinShare(
                                    ShareManager.WEIXIN_SHARE_TYPE_FRENDS, discription, shareUrl);
                        }

                        @Override
                        public void qqShare() {
                            ShareManager.getInstance(MainActivity.this).shareToQQ(MainActivity.this, discription, shareUrl);
                        }

                        @Override
                        public void qzoneShare() {
                            ShareManager.getInstance(MainActivity.this).shareToQzone(MainActivity.this, discription, shareUrl);
                        }
                    });
                }
                shareDialog.show();
            }
        });
    }

    private void openWXinClient(){
        loadingView.setViewType(StudentLoadingLayout.LoadingType.LAODING_COMMON);
        // send oauth request
        api = WXAPIFactory.createWXAPI(this, Constant.WX_AppID);
        api.registerApp(Constant.WX_AppID);
        boolean isInstall = Util.checkBrowser(this,"com.tencent.mm");
        Log.i("king", "isInstall = " + isInstall);
        if(isInstall){
            WXEntryActivity.setListener(this);
            final com.tencent.mm.sdk.modelmsg.SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = "none_weixin_login";
            api.sendReq(req);
            Log.i("king", "sendReq");
        }else{
            Util.showToast(R.string.no_install_weixin);
        }
    }

    private void openQQClient(){
        loadingView.setViewType(StudentLoadingLayout.LoadingType.LAODING_COMMON);
        // Tencent类是SDK的主要实现类，通过此访问腾讯开放的OpenAPI。
        mTencent = Tencent.createInstance(Constant.QQ_AppID, this);
        if(mTencent == null){
            Util.showToast(R.string.no_install_qq);
        }else{
            if (!mTencent.isSessionValid())
            {
                Log.i("king", "QQ login start");
                listener = new QQListener();
                mTencent.login(this, "all", listener);
            }
        }
    }

    @Override
    public void onGetWXLoginCode(String code) {
        getAccessTokenByCode(code, Constant.WX_AppID,
                Constant.WX_AppSecret);
    }

    @Override
    public void onUserCancelOrFail() {
        loadingView.setViewGone();
}

    /**
     * 根据code换取token
     * @param code
     * @param appid
     * @param secret
     */
    private void getAccessTokenByCode(String code , String appid , String secret) {
        loadingView.setViewGone();
    }

    private class QQListener implements IUiListener {

        @Override public void onComplete(Object object) {
            if(object !=  null){
                try{
                    JSONObject jsonObject = (JSONObject)object;
                    //自己处理用户的信息
                    loadingView.setViewGone();
                }catch (Exception e){

                }
            }
        }

        @Override public void onError(UiError uiError) {
            loadingView.setViewGone();
            Log.i("king", "QQ login onError");
            if(uiError!=null){
                Util.showToast(uiError.errorMessage);
                Log.i("king", "code = " + uiError.errorCode + " ,detail = " + uiError.errorMessage);
            }
        }

        @Override public void onCancel() {
            loadingView.setViewGone();
            Log.i("king", "QQ login onCancel");
        }
    }

}
