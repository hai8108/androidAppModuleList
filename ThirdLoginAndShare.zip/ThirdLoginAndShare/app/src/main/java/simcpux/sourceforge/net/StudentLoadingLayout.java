package simcpux.sourceforge.net;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Administrator on 2015/7/10.
 */
public class StudentLoadingLayout extends FrameLayout {

    private Context mContext;
    private RelativeLayout rlCommonLoading;

    private TextView tvContent;
    private ProgressBar pbLoading;

    public enum LoadingType{
        //通用loading
        LAODING_COMMON,
        //答题提交
        LAODING_SUBMMIT,
        //智能出题中loading
        LAODING_INTELLI_EXE;
    }

    public StudentLoadingLayout(Context context) {
        super(context);
        mContext = context;
        initView();
    }

    public StudentLoadingLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initView();
    }

    public StudentLoadingLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
        initView();
    }

    private void initView(){
        setViewGone();
        LayoutInflater.from(mContext).inflate(R.layout.layout_student_loading, this);
        rlCommonLoading = (RelativeLayout) this.findViewById(R.id.rl_common_loading);
        FrameLayout.LayoutParams params = (LayoutParams) rlCommonLoading.getLayoutParams();
        params.gravity = Gravity.CENTER;
        rlCommonLoading.setLayoutParams(params);

        tvContent = (TextView) findViewById(R.id.tv_loading_content);
        pbLoading = (ProgressBar) findViewById(R.id.pb_loaing);

    }

    public void setViewType(LoadingType type){
        switch (type) {
            case LAODING_COMMON:
                this.setVisibility(View.VISIBLE);
                pbLoading.setVisibility(View.VISIBLE);
                tvContent.setVisibility(View.GONE);
                break;
            case LAODING_INTELLI_EXE:
                this.setVisibility(View.VISIBLE);
                pbLoading.setVisibility(View.VISIBLE);
                tvContent.setVisibility(View.VISIBLE);
                tvContent.setText(mContext.getResources().getString(R.string.loading));
                break;
            case LAODING_SUBMMIT:
                this.setVisibility(View.VISIBLE);
                pbLoading.setVisibility(View.VISIBLE);
                tvContent.setVisibility(View.VISIBLE);
//                tvContent.setText(mContext.getResources().getString(R.string.submmit_questions));
                break;
        }
    }


    public void setViewGone(){
        this.setVisibility(View.GONE);
    }


//    public boolean isVisibiliy(){
//        return this.isShown()
//    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return true;
    }
}
