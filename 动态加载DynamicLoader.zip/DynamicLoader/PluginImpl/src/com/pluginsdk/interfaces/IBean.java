package com.pluginsdk.interfaces;

public  interface IBean{
  public  String getName();
  public  void setName(String paramString);
}