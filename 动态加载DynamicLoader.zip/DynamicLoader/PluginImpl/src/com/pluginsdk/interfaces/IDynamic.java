package com.pluginsdk.interfaces;

import android.content.Context;

public interface IDynamic{
  public  void methodWithCallBack(YKCallBack paramYKCallBack);
  public  void showPluginWindow(Context paramContext);
  public  void startPluginActivity(Context context,Class<?> cls);
  public  String getStringForResId(Context context);
}