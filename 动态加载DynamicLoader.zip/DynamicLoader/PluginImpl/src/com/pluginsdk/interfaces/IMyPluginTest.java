package com.pluginsdk.interfaces;

import android.app.Activity;

/**
 * Created by hai8108 on 15/11/27.
 */
public interface IMyPluginTest {
    public String getMyName();
    public String displayMyInfo(Activity activity, String myInfo);
}
