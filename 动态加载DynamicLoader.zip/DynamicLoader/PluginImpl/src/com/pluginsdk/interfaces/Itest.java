package com.pluginsdk.interfaces;

public abstract interface Itest{
  public abstract void test();
}