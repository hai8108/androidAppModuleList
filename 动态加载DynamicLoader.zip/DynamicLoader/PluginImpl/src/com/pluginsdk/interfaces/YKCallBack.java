package com.pluginsdk.interfaces;

public  interface YKCallBack{
  public  void callback(IBean paramIBean);
}