package com.youku.pluginsdk;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.youku.pluginsdk.R;

import android.os.Bundle;
import android.app.Activity;

public class MainActivity extends Activity {
	private static View parentView;
	private Button pluginBtn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(parentView == null) {
			setContentView(R.layout.activity_main);
		} else {
			setContentView(parentView);
		}
		pluginBtn = (Button) findViewById(R.id.plugin_btn);
		pluginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Toast.makeText(getApplicationContext(), "I came from plugin module", Toast.LENGTH_SHORT).show();
			}
		});
	}
	public static void setLayoutView(View view){
		parentView = view;
	}
}
