package com.youku.pluginsdk.imp;

import android.app.Activity;
import android.widget.Toast;
import com.pluginsdk.interfaces.IMyPluginTest;

/**
 * Created by hai8108 on 15/11/27.
 */
public class MyPluginTest implements IMyPluginTest {
    @Override
    public String getMyName() {
        return "my name is haitian!";
    }

    @Override
    public String displayMyInfo(Activity activity, String s) {
        if(!activity.isFinishing()){
            Toast.makeText(activity, "show my name "+s, Toast.LENGTH_SHORT).show();
        }
        return s;
    }
}
